
public class Complexo {

	//atributos ou propriedades ou vari�vel de inst�ncia
	double real;
	double imaginaria;
	
	//m�todo construtor
	public Complexo(double real,double imaginaria) {
		this.real = real;
		this.imaginaria = imaginaria;
		
	}
	
	//m�todo construtor sobrecarregado
	public Complexo(double imaginaria) {
		this(0,imaginaria); //chamada para o outro m�todo construtor 
		
	}
	
	//retornar os dados do n�mero complexo
	public String retornarDados(){
		String aux = "z = "+real+imaginaria+"i";
		return aux;
	}
}
