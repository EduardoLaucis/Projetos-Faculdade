import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;
import static java.lang.Double.parseDouble;

public class Principal {

	public static void main(String[] args) {

		int opcao;
		double real, imaginaria;
		Complexo c1=null;

		do {
			opcao = parseInt(showInputDialog(gerarMenu()));
			if (opcao < 1 || opcao > 6) {
				showMessageDialog(null, "Op��o Inv�lida", "ERRO", ERROR_MESSAGE);
			} else {
				switch (opcao) {
				case 1:
					real = parseDouble(showInputDialog("Parte real "));
					imaginaria = parseDouble(showInputDialog("Parte imagin�ria"));
					c1 = new Complexo(real, imaginaria);
					break;
				case 5:
					showMessageDialog(null, c1.retornarDados());
					
					

				}
			}
		} while (opcao != 6);
	}

	public static String gerarMenu() {
		String aux = "";
		aux += "Escolha uma op��o\n";
		aux += "1. Gerar 1� n�mero complexo\n";
		aux += "2. Gerar 2� n�mero complexo\n";
		aux += "3. Gerar 3� n�mero complexo\n";
		aux += "4. Somar\n";
		aux += "5. Imprimir\n";
		aux += "6. Sair\n";
		return aux;
	}

}
