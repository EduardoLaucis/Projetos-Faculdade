import java.util.Scanner;

public class TesteBicicleta {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		//instancia��o dos 3 objetos
		Bicicleta b1 = new Bicicleta("vermelha",2,150);
		Bicicleta b2 = new Bicicleta("rosa",5,35);
		Bicicleta b3 = new Bicicleta("azul",3,20);
		
		//chamada do m�todo
		Bicicleta aux = maisCara(b1, b2, b3);
		
		//impress�o dos dados da bicicleta mais cara
		System.out.println(aux.retornarDados());
	}

		public static  Bicicleta maisCara(Bicicleta b1, Bicicleta b2, Bicicleta b3) {
			Bicicleta aux = null;
			if(b1.valor > b2.valor && b1.valor > b3.valor) {
				aux = b1;
			}
			else if(b2.valor > b3.valor) {
				aux = b2;
			}
			else {
				aux = b3;
			}
			return aux;
		}
}
