import java.util.Scanner;

public class TesteAluno {

	public static void main(String[] args) {
	Scanner leitor = new Scanner(System.in);
	Aluno a1 = new Aluno();
	
	System.out.println("Nome-> ");
	a1.nome = leitor.nextLine();
	System.out.println("Nota1:");
	a1.digitarNota1=leitor.nextDouble();
	System.out.println("Nota2:");
	a1.digitarNota2=leitor.nextDouble();
	System.out.println(a1.retornarDados());
	
	leitor.close();
	}

	

}
