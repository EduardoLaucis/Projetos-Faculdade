
public class Bicicleta {
	String cor;
	int marcha;
	double valor,maiorvalor;
	
	public Bicicleta(String cor , int marcha, double valor) {
		this.cor = cor;
		this.marcha = marcha;
		this.valor = valor;
	}
	public Bicicleta(String cor) {
		this.cor = cor;
	}
	public String retornarDados() {
		return "Cor da bicicleta: " + cor + "\nMarcha: " + marcha + "\nR$:" + valor ;
	}
	
}
