
public class Aluno {

	String nome;
	double nota1,nota2,media;
	String digitarNome;
	double digitarNota1;
	double digitarNota2;
	String retornarDados;
	public String digitarNome() {
		return "Nome: " + nome;
	}
	public String digitarNota1(double nota1) {
		return "\nNota1: " + nota1;
	}
	public String digitarNota2(double nota2) {
		return "\nNota2: " + nota2;
	}
	public double media(double nota1,double nota2) {
		media = (nota1+nota2)/2;
		return media;
	}
	public boolean situacao() {
		
		if(media>=6) 
			return true;
		else
			return false;
		
	}
	public String retornarDados() {
		return "Nome: " + nome + "\nM�dia: " + media(digitarNota1,digitarNota2) + "\nSitua��o: " + situacao();
	}
	
}
