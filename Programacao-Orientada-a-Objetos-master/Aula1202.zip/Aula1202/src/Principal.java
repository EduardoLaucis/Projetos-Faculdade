import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Paciente p1 = new Paciente();
		
		//entrada de dados
		System.out.println("Nome do paciente -> ");
		p1.nome = teclado.nextLine();
		System.out.println("Idade do paciente -> ");
		p1.idade = teclado.nextInt();
		 
		//Sa�da de dados
		System.out.println("Nome: " +p1.nome + "\nIdade: " + p1.idade);
		teclado.close();
	}

}
