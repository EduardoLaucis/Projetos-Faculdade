
public class Paciente {
	
	//atributo ou propriedade ou vari�vel de inst�ncia
	String nome;
	int idade;
	
	//m�todo para calcular a frequ�ncia m�xima
	public int frequenciaMaxima(){
		return 220-idade;
	}
	
	//m�todo para calcular o alvo m�nimo
	public double alvoMinimo(){
		return frequenciaMaxima()*0.5;
		
	}
	//m�todo para calcular o alvo m�ximo
	public double alvoMaximo(){
		return frequenciaMaxima() * 0.85;
		
	}
	
}


