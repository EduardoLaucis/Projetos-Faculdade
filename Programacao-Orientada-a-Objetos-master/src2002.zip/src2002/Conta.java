
public class Conta {
	// atributos ou propriedades ou vari�veis de inst�ncia
	int numero;
	double saldo;
	double limite;

	// m�todo para sacar um valor
	public void sacar(double valor) {
		saldo -= valor;
	}
	
	//m�todo para depositar um valor na conta
	public void depositar(double valor) {
		saldo += valor;
	}
	
	//m�todo para retornar o saldo do cliente
	public double consultarSaldo() {
		return saldo;
	}
	
	public String retornarDados() {
		String aux = "";
		aux += "N�mero da Conta -> " + numero + "\n";
		aux += "Saldo -> R$ " + saldo + "\n";
		aux += "limite -> R$ "+ limite + "\n";
		return aux;
	}
}
