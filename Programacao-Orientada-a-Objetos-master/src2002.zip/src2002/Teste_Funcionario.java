
public class Teste_Funcionario {

	public static void main(String[] args) {

		System.out.println(Funcionario.vale);
		System.out.println(Funcionario.vale);
		
		Funcionario.aumentarVale(10);
		
		System.out.println(Funcionario.vale);
		System.out.println(Funcionario.vale);
	}

}
