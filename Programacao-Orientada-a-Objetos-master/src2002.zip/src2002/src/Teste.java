package src;

public class Teste {
	
	
	
	public static void main(String[] args) {
	
		int[] vi = {1,2,3};
		double[] vd= {1.1,2,2.3,3};
		String[] vs = {"sono","cama","pregui�a"};
		
		

	}
	
	public static void imprimir(int[] vi) {
		for(int i=0; i<vi.length;i++) {
			System.out.println(vi[i]+ " ");
		}
	}	
	public static void imprimir(double[] vi) {
			for(int i=0; i<vi.length;i++) {
				System.out.println(vi[i]+ " ");
			}
	}		
	public static void imprimir(String[] vi) {
				for(int i=0; i<vi.length;i++) {
					System.out.println(vi[i]+ " ");
			}
				
	}

}
