import static javax.swing.JOptionPane.*;

public class Principal {

	public static void main(String[] args) {
		
		//String nome = JOptionPane.showInputDialog("Informe o nome");
		//int rm = Integer.parseInt(JOptionPane.showInputDialog("RM"));

		//Aluno aluno = new Aluno(rm,nome);
		
		//JOptionPane.showMessageDialog(null,aluno.retornarDados());
		
		int resp = showConfirmDialog(null,"Deseja finalizar?");
		if(resp==0) {
			showMessageDialog(null,"Fica,vai!");
		}
		else {
			showMessageDialog(null,"Presta aten��o Man�!","ALERTA",ERROR_MESSAGE);
		}
	}

}
