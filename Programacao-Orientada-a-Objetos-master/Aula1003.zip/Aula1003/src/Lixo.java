
public class Lixo {

	public static void main(String[] args) {

		Runtime rt = Runtime.getRuntime();
		System.out.println("Mem�ria total da JVM -> " + rt.totalMemory());
		System.out.println("Antes da coleta -> " + rt.freeMemory());
		Aluno aluno = null;
		for (int i = 0; i < 100000; i++) {
			aluno = new Aluno(i, "xyz");
			aluno = null;
		}
		System.out.println("Mem�ria total da JVM -> " + rt.totalMemory());

		rt.gc();

		System.out.println("Depois da coleta -> " + rt.freeMemory());

	}

}
