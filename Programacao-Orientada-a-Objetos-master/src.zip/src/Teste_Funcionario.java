
public class Teste_Funcionario {

	public static void main(String[] args) {

		Funcionario f1 = new Funcionario();
		Funcionario f2 = new Funcionario();
		
		System.out.println(f1.vale);
		System.out.println(f2.vale);
		
		f1.aumentarVale(10);
		
		System.out.println(f1.vale);
		System.out.println(f2.vale);
	}

}
