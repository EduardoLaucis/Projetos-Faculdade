
public class TesteConta {

	public static void main(String[] args) {

		Conta joao = new Conta();
		joao.saldo=1500;

		
		Conta maria = new Conta();
		maria.saldo = 2000;
		
		maria.transferir(joao, 500);
		
		System.out.println("Maria-> " + maria.saldo);
		System.out.println("Jo�o-> " + joao.saldo);
		
		joao.transferir(maria, 700);
		
		System.out.println("Maria-> " + maria.saldo);
		System.out.println("Jo�o-> " + joao.saldo);
		
		
	}

}
