
public class Principal {

	public static void main(String[] args) {
		
		Aluno a = new Aluno();
		System.out.println(a);
		System.out.println(a.rm);
		System.out.println(a.nome);
		
	}
}
