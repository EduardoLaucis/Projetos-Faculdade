
public class Aluno {

	//atributos ou propriedades ou vari�vel de inst�ncia
	int rm;
	String nome;
	
	
	
}
