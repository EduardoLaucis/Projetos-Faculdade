import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		Retangulo r1 = new Retangulo(3,4);
		Retangulo r2 = new Retangulo(6,9);
		
		Retangulo aux = r1.comparar(r2);
		
		System.out.println(r1.retornarDados());
		System.out.println();
		System.out.println(r2.retornarDados());
		System.out.println("Ret�ngulo com maior �rea: ");
		System.out.println(aux.retornarDados());
	
	}
}
	
	


