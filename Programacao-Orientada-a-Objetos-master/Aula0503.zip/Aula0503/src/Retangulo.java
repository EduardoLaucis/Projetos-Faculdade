
public class Retangulo {
	double base,altura;
	
	public Retangulo(double base,double altura) {
		this.base=base;
		this.altura=altura;
	}
	public Retangulo() {
		this(1,1);
	}
	public double calcularArea(){
		return base*altura;
	}
	public double calcularPerimetro() {
		return 2*(base+altura);
	}
	
	public String retornarDados(){
		String aux = "";
		aux += "base -> " + base + "\n";
		aux += "altura-> " + altura +"\n";
		aux += "�rea-> " + calcularArea() + "\n";
		aux += "per�metro-> " + calcularPerimetro()+ "\n";
		return aux;
	}
	public Retangulo comparar(Retangulo r) {
		if(this.calcularArea()>r.calcularArea()) {
			return this;
		}
		
		return r;
	}
	
}
