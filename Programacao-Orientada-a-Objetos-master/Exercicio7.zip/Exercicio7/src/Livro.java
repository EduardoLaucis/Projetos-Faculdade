
public class Livro {

	//atributo da vari�vel livro
	String titulo;
	String genero;
	Autor autor = new Autor();
	public String retornarDados() {
		
		return "T�tulo: " + titulo + ";\nG�nero: " + genero + ";\n" + autor.retornarDados();
	}
}
