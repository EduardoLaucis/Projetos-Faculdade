
public class Autor {

	//atributo da vari�vel autor
	String nome;
	String cidade;
	
	public String retornarDados() {
		
		return "Nome:  " + nome + ";\nCidade Natal:" + cidade;
	}
}
