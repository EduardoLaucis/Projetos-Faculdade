import java.util.Scanner;

public class Exibir {

	public static void main(String[] args) {

		Scanner leitor = new Scanner(System.in);

		//objeto livro
		Livro livro1 = new Livro();
		System.out.println("Titulo-> ");
		livro1.titulo = leitor.nextLine();
		System.out.println("G�nero-> ");
		livro1.genero = leitor.nextLine();
		System.out.println("Nome do autor-> ");
		livro1.autor.nome = leitor.nextLine();
		System.out.println("Cidade do autor-> ");
		livro1.autor.cidade = leitor.nextLine();
		
		System.out.println(livro1.retornarDados());
		
		
		leitor.close();
	}

}
