package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.agenda.Agenda;
import br.fiap.conexao.Conexao;

public class AgendaDAO { //DAO -> Data Access Object -> respons�vel por conter as operacoes de banco de dados

	private PreparedStatement p; //Respons�vel por realizar as opera��es SQL no banco de dados
	private String sql; //Respons�vel por armazenar a instru��o SQL que ser� enviada para o banco
	private ResultSet rs; //Respons�vel por armazenar o resultado de um SELECT
	private Connection connection; //Respons�vel por armazenar a conex�o estabelecida com o banco de dados
	
	public boolean inserir(Agenda agenda) {
		sql = "insert into AGENDA (nome, email, endereco, nascimento) values (?, ?, ?, ?)";
		connection = new Conexao().conectar();
		try{
			p = connection.prepareStatement(sql);
			p.setString(1, agenda.getNome());
			p.setString(2, agenda.getEmail());
			p.setString(3, agenda.getEndereco());
			p.setString(4, agenda.getNascimento());
			p.execute(); //Usado somente para INSERT, UPDATE, DELETE
			return true;
			
		} catch (SQLException e) {
			System.out.println("Erro ao inserir dados no banco\n" + e);
		}
		return false;
	}
	
	public Agenda pesquisar(String nome, String email) {
		Agenda agenda = null;
		sql = "select * from AGENDA where nome = ? and email = ?";
		connection = new Conexao().conectar();
		try{
			p = connection.prepareStatement(sql);
			p.setString(1, nome);
			p.setString(2, email);
			rs = p.executeQuery(); //Usado apenas para o SELECT
			if(rs.next()) // Se for verdadeiro, dado encontrado!
			{
				agenda = new Agenda(nome, email, rs.getString("endereco"), rs.getNString("nascimento"));
			}
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar dados no banco\n" + e);
		}
		return agenda;
	}
	
	public List<Agenda> listar() {
		List<Agenda> lista = null;
		sql = "select * from AGENDA";
		connection = new Conexao().conectar();
		try{
			p = connection.prepareStatement(sql);
			rs = p.executeQuery(); //Usado apenas para o SELECT
			lista = montarLista(rs);
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar dados no banco\n" + e);
		}
		return lista;
	}

	private List<Agenda> montarLista(ResultSet rs) throws SQLException {
		List<Agenda> lista = new ArrayList<Agenda>();
		String nome, email, endereco, nascimento;
		
		while(rs.next()) {
			nome = rs.getNString("nome");
			email = rs.getNString("email");
			endereco = rs.getString("endereco");
			nascimento = rs.getString("nascimento");
			lista.add(new Agenda(nome, email, endereco, nascimento));
		}
		
		return lista;
	}
}
