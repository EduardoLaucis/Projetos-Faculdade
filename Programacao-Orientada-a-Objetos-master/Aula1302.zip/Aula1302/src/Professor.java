import java.util.Scanner;
public class Professor {
	
	//atributos
	String nome,titulacao;
	double valorHoraAula;
	int totalDeAulas;
		
	//calcular e retornar o sal�rio do professor
	public double calcularSalario() {
		double salario,sb,dsr,ha;
		
		//sal�rio base
		sb = valorHoraAula*4.5*totalDeAulas;
		if(titulacao.equalsIgnoreCase("mestre")) {
			sb *=1.03;
		}
		else if(titulacao.equalsIgnoreCase("doutor")) {
			sb *= 1.085;
		}
		
		//hora atividade
		ha = sb*0.05;
		
		//descanso semanal renumerado
		dsr = (sb+ha)/6;
		
		salario = sb+ha+dsr;
		return salario;

	}

	//m�todo para aplicar um aumento no valor da hora aula
	public void ajustarValorAula(double porcentagem) {
		valorHoraAula *= (1+porcentagem/100);
	}
}
