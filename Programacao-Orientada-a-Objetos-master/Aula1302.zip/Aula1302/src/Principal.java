import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		Professor p = new Professor();
		
		//entrada de dados
		System.out.println("Nome do professor -> ");
		p.nome = teclado.nextLine();
		System.out.println("Titula��o (mestre ou doutor)-> ");
		p.titulacao = teclado.nextLine();
		System.out.println("Valor da aula -> R$ ");
		p.valorHoraAula = teclado.nextDouble();
		
		teclado.close();

	}

}
