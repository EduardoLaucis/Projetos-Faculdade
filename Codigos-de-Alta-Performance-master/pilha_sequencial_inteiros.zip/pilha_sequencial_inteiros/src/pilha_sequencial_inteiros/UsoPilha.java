package pilha_sequencial_inteiros;

import pilha_sequencial_inteiros.PilhaInt.RetornoInt;

public class UsoPilha {

	public static void main(String[] args) {

		PilhaInt pilha = new PilhaInt();
		RetornoInt res = new RetornoInt();
		
		pilha.init();
		
		pilha.push(10);
		
		res = pilha.pop();
		if(res.sucesso==true)
			System.out.println("Valor retirado " + res.elem );
		else
			System.out.println("Pilha vazia");
		

	}

}
