package pilha_sequencial_inteiros;

public class PilhaInt {

	public final int  N = 6;

	int dados[] = new int[N];
	int topo;
	
	public static class RetornoInt{
		public int elem;
		public boolean sucesso;
	}

	public void init() {
		topo = 0;
	}

	public boolean isEmpty(){
		if (topo==0)
			return true;
		else
			return false;
	}
	
	public void push(int elem) {
		dados[topo]=elem;
		topo++;
	}

	public RetornoInt pop() {
		RetornoInt saida = new RetornoInt();
		if(isEmpty()==false) {
			topo--;
			saida.elem = dados[topo];
			saida.sucesso = true;
		}
		else
			saida.sucesso = false;
		
		return saida;
	}


}



