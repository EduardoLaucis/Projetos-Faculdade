package pilha_sequencial_inteiros;

import pilha_sequencial_inteiros.PilhaInt.RetornoInt;

public class UsoPilha {

	public static void main(String[] args) {

		PilhaInt pilha = new PilhaInt();
		RetornoInt res = new RetornoInt();
		
		pilha.init();
		
		pilha.push(10);
		pilha.push(12);
		pilha.push(22);
		pilha.push(33);
		pilha.push(44);
		pilha.push(55);
		pilha.push(66);
		pilha.push(77);
		
		res = pilha.pop();
		if(res.sucesso==true)
			System.out.println("Valor retirado: " + res.elem);
		
		

	}

}
